import {test, Locator, Page} from "@playwright/test"
 

export class loginpage{

// blue print of the login functionality 
 
//username, password , login are the actions available 
page:Page
usernameinputfield:Locator
passwordinputfield:Locator
loginbutton:Locator

constructor(page:Page){
    this.page = page
    this.usernameinputfield = this.page.locator("#user-name")
    this.passwordinputfield = this.page.locator("#password")
    this.loginbutton = this.page.locator("#login-button")
}
 async fillusername(username:string):Promise<void>{
  await test.step("fill username",async()=>{
  await  this.usernameinputfield.fill(username)
})
 }

 async fillpassword(password:string):Promise<void>{
   await test.step("fill password",async()=>{
      await this.passwordinputfield.fill(password)
    })
   
 }

 async clickloginbutton():Promise<void>{

   await test.step("click loginbutton",async()=>{
      await this.loginbutton.click()
    })
 }


}