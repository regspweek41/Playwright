export async function createIncident()
{

}