class Users{
    name:string
    age:number
    constructor(name:string,age:number)
    {
      this.name = name 
      this.age = age 
    }
    printinfo(){
        console.log(`${this.name} has age ${this.name}`)
    }
}

const user1 = new Users("tom",30)
const user2 = new Users("tomm",30)
console.log(user1.name)
console.log(user1.age)
console.log(user2.name)
console.log(user2.age)