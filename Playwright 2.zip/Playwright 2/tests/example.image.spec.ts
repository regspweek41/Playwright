// import {test,expect} from "@playwright/test"


// test.describe.only(`API - Image`,async()=>{
//     test.describe.configure({mode:"serial"}) 
//      const siteurl = "https://thinking-tester-contact-list.herokuapp.com"

//      test(`Verify the image assertion `,async({page})=>{
    
//         //go to the side
//         await page.goto(siteurl)
       
//     await expect(page,`expect res code to have 201`).toHaveScreenshot('landing-page.png')
//     })

//     test(`Verify the image logo assertion `,async({page})=>{
    
//         //go to the side
//         await page.goto(siteurl)
//         const logo = page.locator("#login-button")
       
//     await expect(logo).toHaveScreenshot('landing-page.png')
//     mask:[page.locator("#login-button")]
//     })


// })