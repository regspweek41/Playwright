import {test,expect} from "@playwright/test"
import { loginpage } from "../login-objects/loginpage";
import { AppConstants } from "../constants/appConstant";

test.only(`Understanding locator.all`,async({page})=>{

    //login
    await page.goto(AppConstants.Instanceurl)
    const loginPage = new loginpage(page)
    await loginPage.fillusername("standard-user")
    await loginPage.fillpassword("secre-sauce")
    await loginPage.clickloginbutton()
})