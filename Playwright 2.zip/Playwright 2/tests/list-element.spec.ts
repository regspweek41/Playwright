import {test,expect} from "@playwright/test"

test.only(`Understanding locator.all`,async({page})=>{

    //login
    await page.goto("https://www.saucedemo.com/v1/index.html")
    await page.locator("#user-name").fill("standard_user")
    await page.locator("#password").fill("secret_sauce")
    await page.locator("#login-button").click()
    await expect(page.locator(".inventory_item"),`expecting inventory card to be 6`).toHaveCount(6)
    const listOfAllInventoryCards = await page.locator(".inventory_item").all()
    //iterate over an array
    const listSize = listOfAllInventoryCards.length
    //for loop i=0
    for(let i=0;i<listSize;i++){
        const priceOfTheItem = await page.locator(".inventory_item").nth(i).locator(".inventory_item_price").textContent()
        console.log(`price of the items is ${priceOfTheItem}`)
    }
})