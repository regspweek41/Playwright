var Users = /** @class */ (function () {
    function Users(name, age) {
        this.name = name;
        this.age = age;
    }
    Users.prototype.printinfo = function () {
        console.log("".concat(this.name, " has age ").concat(this.name));
    };
    return Users;
}());
var user1 = new Users("tom", 30);
console.log(user1.name);
console.log(user1.age);
