
export  enum AppConstants {
    Instanceurl = "https://www.saucedemo.com/v1/index.html"
}
